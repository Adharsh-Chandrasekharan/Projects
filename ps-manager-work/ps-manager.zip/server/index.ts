
import 'dotenv/config';

import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import jwt from 'jsonwebtoken';
import { timingSafeEqual } from 'node:crypto';
import { SqlServer } from '../electron/sqlServer';

const app = express();
const db = new SqlServer();

const PORT = Number(process.env.PORT || 8080);
const JWT_SECRET = process.env.JWT_SECRET || '';
const ADMIN_USERNAME = process.env.API_ADMIN_USERNAME || '';
const ADMIN_PASSWORD = process.env.API_ADMIN_PASSWORD || '';

if (!JWT_SECRET || !ADMIN_USERNAME || !ADMIN_PASSWORD) {
  throw new Error('API authentication environment variables are missing.');
}

const allowedOrigins = (
  process.env.WEB_ORIGIN || 'http://localhost:5173'
).split(',').map(value => value.trim());

app.use(helmet());

app.use(cors({
  origin(origin, callback) {
    if (!origin || origin === 'null' || allowedOrigins.includes(origin)) {
      return callback(null, true);
    }
    callback(new Error('Origin not allowed.'));
  },
  allowedHeaders: ['Content-Type', 'Authorization'],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
}));

app.use(express.json({ limit: '1mb' }));

function safeEqual(a: string, b: string): boolean {
  const left = Buffer.from(a);
  const right = Buffer.from(b);

  return left.length === right.length &&
    timingSafeEqual(left, right);
}

function authenticate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  const header = req.headers.authorization;

  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authentication required.' });
  }

  try {
    jwt.verify(header.slice(7), JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: 'Invalid or expired token.' });
  }
}

function asyncRoute(
  handler: (req: Request, res: Response) => Promise<unknown>
) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(handler(req, res)).catch(next);
  };
}

// Public health check
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', service: 'GRINDxGAMING API' });
});

// Login
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};

  if (
    typeof username !== 'string' ||
    typeof password !== 'string' ||
    !safeEqual(username, ADMIN_USERNAME) ||
    !safeEqual(password, ADMIN_PASSWORD)
  ) {
    return res.status(401).json({ message: 'Invalid credentials.' });
  }

  const token = jwt.sign(
    { sub: ADMIN_USERNAME, role: 'admin' },
    JWT_SECRET,
    { expiresIn: '8h' }
  );

  res.json({ token, expiresIn: 28800 });
});

// All following routes require authentication
app.use('/api', authenticate);

// Get all consoles
app.get('/api/consoles', asyncRoute(async (_req, res) => {
  res.json(await db.getAllPlaystations());
}));

// Add console
app.post('/api/consoles', asyncRoute(async (req, res) => {
  const id = await db.addPlaystation(req.body);
  res.status(201).json({ id });
}));

// Get active session
app.get('/api/consoles/:id/session', asyncRoute(async (req, res) => {
  const session = await db.getSession(Number(req.params.id));
  res.json(session);
}));

// Update console rates
app.put('/api/consoles/:id/rates', asyncRoute(async (req, res) => {
  await db.updateConsoleRates(
    Number(req.params.id),
    req.body.rates
  );
  res.json({ success: true });
}));

// Delete console
app.delete('/api/consoles/:id', asyncRoute(async (req, res) => {
  await db.deletePlaystation(Number(req.params.id));
  res.json({ success: true });
}));

// Ledger: current billing versions only. Date boundaries are session EndTime.
app.get('/api/ledger', asyncRoute(async (req, res) => {
  const from = String(req.query.from || '');
  const to = String(req.query.to || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to) || from > to) {
    return res.status(400).json({ message: 'Provide a valid date range.' });
  }
  res.json(await db.getLedger(from, to));
}));

app.get('/api/ledger/:sessionId/history', asyncRoute(async (req, res) => {
  res.json(await db.getBillingHistory(Number(req.params.sessionId)));
}));

app.put('/api/ledger/:billingId', asyncRoute(async (req, res) => {
  res.json(await db.editBilling(Number(req.params.billingId), req.body || {}));
}));

app.delete('/api/ledger/:billingId', asyncRoute(async (req, res) => {
  await db.deleteBilling(Number(req.params.billingId), String(req.body?.reason || ''));
  res.json({ success: true });
}));

// Reset all data. This is deliberately protected by JWT authentication
// and requires an explicit confirmation phrase from the administrator.
app.post('/api/admin/reset', asyncRoute(async (req, res) => {
  if (req.body?.confirmation !== 'RESET ALL DATA') {
    return res.status(400).json({ message: 'Explicit reset confirmation is required.' });
  }

  await db.resetAll();
  res.json({ success: true });
}));

// Reserve console
app.post('/api/sessions/reserve', asyncRoute(async (req, res) => {
  const { PlayStationID, PlayersNumber, DurationMinutes, DiscountPercent } =
    req.body;

  const result = await db.reserve(
    Number(PlayStationID),
    Number(PlayersNumber),
    Number(DurationMinutes),
    Number(DiscountPercent ?? 0)
  );

  res.status(201).json(result);
}));

// End session and create billing record
app.post('/api/sessions/end', asyncRoute(async (req, res) => {
  const result = await db.endSession(
    Number(req.body.PlayStationID)
  );
  res.json(result);
}));

// Add players
app.post('/api/sessions/add-players', asyncRoute(async (req, res) => {
  await db.addPlayers(
    Number(req.body.PlayStationID),
    Number(req.body.additionalPlayers)
  );
  res.json({ success: true });
}));

// Extend session
app.post('/api/sessions/extend', asyncRoute(async (req, res) => {
  await db.extendTime(
    Number(req.body.PlayStationID),
    Number(req.body.additionalMinutes)
  );
  res.json({ success: true });
}));

app.get('/api/health/database', asyncRoute(async (_req, res) => {
    await db.getAllPlaystations();
    res.json({ status: 'connected' });
  }));

app.use((
  error: Error,
  _req: Request,
  res: Response,
  _next: NextFunction
) => {
  console.error('[API ERROR]', error.message);
  res.status(400).json({ message: error.message || 'Request failed.' });
});

const server = app.listen(PORT, () => {
  console.log(`[API] GRINDxGAMING API running on port ${PORT}`);
});

async function shutdown() {
  server.close();
  await db.close().catch(console.error);
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
