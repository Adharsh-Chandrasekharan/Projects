"use strict";
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
const electron = require("electron");
const path = require("node:path");
const fs = require("node:fs");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const fs__namespace = /* @__PURE__ */ _interopNamespaceDefault(fs);
const IPC = {
  createPlaystation: "Create Playstation",
  getAllPlaystations: "Get All Playstations",
  getSession: "Get Session",
  Reserve: "Start Session",
  End: "End Session",
  AddPlayers: "Add Players",
  ExtendTime: "Extend Time",
  UpdateRates: "Update Console Rates",
  Delete: "Delete Console",
  Reset: "Reset DataBase",
  // Legacy local-password channels retained for source compatibility; no handlers are registered.
  getPass: "get password from json",
  UpdataPassword: "Update Admin Password",
  Login: "API Login",
  AuthStatus: "API Auth Status",
  Logout: "API Logout",
  AuthExpired: "API Auth Expired"
};
class Ipc {
  constructor(win2, apiBaseUrl) {
    __publicField(this, "token", null);
    __publicField(this, "tokenExpiresAt", 0);
    __publicField(this, "apiBaseUrl");
    this.win = win2;
    this.apiBaseUrl = apiBaseUrl.replace(/\/+$/, "");
    const clearAuthentication = () => {
      this.token = null;
      this.tokenExpiresAt = 0;
    };
    const request = async (endpoint, method = "GET", body) => {
      if (!this.token || Date.now() >= this.tokenExpiresAt) {
        clearAuthentication();
        throw new Error("Your login has expired. Please sign in again.");
      }
      const response = await fetch(`${this.apiBaseUrl}${endpoint}`, {
        method,
        headers: {
          Authorization: `Bearer ${this.token}`,
          ...body !== void 0 ? { "Content-Type": "application/json" } : {}
        },
        ...body !== void 0 ? { body: JSON.stringify(body) } : {}
      });
      const payload = await response.json().catch(() => ({}));
      if (response.status === 401) {
        clearAuthentication();
        this.win.webContents.send(IPC.AuthExpired);
      }
      if (!response.ok) {
        throw new Error((payload == null ? void 0 : payload.message) || `API request failed (${response.status}).`);
      }
      return payload;
    };
    electron.ipcMain.handle(IPC.AuthStatus, async () => {
      if (!this.token || Date.now() >= this.tokenExpiresAt) {
        clearAuthentication();
        return { authenticated: false };
      }
      return { authenticated: true };
    });
    electron.ipcMain.handle(IPC.Login, async (_event, credentials) => {
      try {
        const response = await fetch(`${this.apiBaseUrl}/api/auth/login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            username: String((credentials == null ? void 0 : credentials.username) || ""),
            password: String((credentials == null ? void 0 : credentials.password) || "")
          })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok || typeof (payload == null ? void 0 : payload.token) !== "string") {
          throw new Error((payload == null ? void 0 : payload.message) || "Login failed. Check your username and password.");
        }
        this.token = payload.token;
        const expiresIn = Number(payload.expiresIn || 28800);
        this.tokenExpiresAt = Date.now() + expiresIn * 1e3;
        return { code: 1 };
      } catch (error) {
        return {
          code: 0,
          msg: error instanceof Error ? error.message : String(error)
        };
      }
    });
    electron.ipcMain.handle(IPC.Logout, async () => {
      clearAuthentication();
      return { code: 1 };
    });
    electron.ipcMain.handle(IPC.getAllPlaystations, async () => {
      try {
        return { code: 1, msg: await request("/api/consoles") };
      } catch (error) {
        return { code: 0, msg: error instanceof Error ? error.message : String(error) };
      }
    });
    electron.ipcMain.handle(IPC.createPlaystation, async (_event, args) => {
      try {
        const created = await request("/api/consoles", "POST", args);
        const consoles = await request("/api/consoles");
        return {
          code: 1,
          msg: consoles.find((item) => Number(item.PlayStationID) === Number(created.id))
        };
      } catch (error) {
        return { code: 0, msg: error instanceof Error ? error.message : String(error) };
      }
    });
    electron.ipcMain.handle(IPC.getSession, async (_event, args) => {
      try {
        const session = await request(`/api/consoles/${Number(args.PlayStationID)}/session`);
        return session ? { code: 1, msg: session } : { code: 0, msg: "No active session found for this console." };
      } catch (error) {
        return { code: 0, msg: error instanceof Error ? error.message : String(error) };
      }
    });
    electron.ipcMain.handle(IPC.Reserve, async (_event, args) => {
      try {
        const result = await request("/api/sessions/reserve", "POST", args);
        return { code: 1, msg: result };
      } catch (error) {
        return { code: 0, msg: error instanceof Error ? error.message : String(error) };
      }
    });
    electron.ipcMain.handle(IPC.End, async (_event, args) => {
      try {
        const result = await request("/api/sessions/end", "POST", args);
        return { code: 1, msg: result };
      } catch (error) {
        return { code: 0, msg: error instanceof Error ? error.message : String(error) };
      }
    });
    electron.ipcMain.handle(IPC.AddPlayers, async (_event, args) => {
      try {
        const result = await request("/api/sessions/add-players", "POST", args);
        return { code: 1, msg: result };
      } catch (error) {
        return { code: 0, msg: error instanceof Error ? error.message : String(error) };
      }
    });
    electron.ipcMain.handle(IPC.ExtendTime, async (_event, args) => {
      try {
        const result = await request("/api/sessions/extend", "POST", args);
        return { code: 1, msg: result };
      } catch (error) {
        return { code: 0, msg: error instanceof Error ? error.message : String(error) };
      }
    });
    electron.ipcMain.handle(IPC.UpdateRates, async (_event, args) => {
      try {
        const result = await request(`/api/consoles/${Number(args.PlayStationID)}/rates`, "PUT", {
          rates: args.rates
        });
        return { code: 1, msg: result };
      } catch (error) {
        return { code: 0, msg: error instanceof Error ? error.message : String(error) };
      }
    });
    electron.ipcMain.handle(IPC.Delete, async (_event, args) => {
      try {
        const result = await request(`/api/consoles/${Number(args.PlayStationID)}`, "DELETE");
        return { code: 1, msg: result };
      } catch (error) {
        return { code: 0, msg: error instanceof Error ? error.message : String(error) };
      }
    });
    electron.ipcMain.handle(IPC.Reset, async (_event, args) => {
      try {
        const result = await request("/api/admin/reset", "POST", {
          confirmation: String((args == null ? void 0 : args.confirmation) || "")
        });
        return { code: 1, msg: result };
      } catch (error) {
        return { code: 0, msg: error instanceof Error ? error.message : String(error) };
      }
    });
  }
}
const distPath = path.join(__dirname, "../dist");
process.env.DIST = distPath;
process.env.VITE_PUBLIC = electron.app.isPackaged ? distPath : path.join(distPath, "../public");
const envPath = electron.app.isPackaged ? path.join(electron.app.getPath("appData"), "PlayStationManager", ".env") : path.resolve(process.cwd(), ".env");
function loadEnvironmentFile(filePath) {
  if (!fs__namespace.existsSync(filePath))
    return;
  const contents = fs__namespace.readFileSync(filePath, "utf8");
  for (const line of contents.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#"))
      continue;
    const separator = trimmed.indexOf("=");
    if (separator < 1)
      continue;
    const key = trimmed.slice(0, separator).trim();
    let value = trimmed.slice(separator + 1).trim();
    if (value.startsWith('"') && value.endsWith('"') || value.startsWith("'") && value.endsWith("'")) {
      value = value.slice(1, -1);
    }
    process.env[key] = value;
  }
}
loadEnvironmentFile(envPath);
const VITE_DEV_SERVER_URL = process.env.VITE_DEV_SERVER_URL;
const API_BASE_URL = process.env.API_BASE_URL || "http://localhost:8080";
let win = null;
function createWindow() {
  win = new electron.BrowserWindow({
    minHeight: 780,
    minWidth: 1180,
    show: false,
    icon: path.join(process.env.VITE_PUBLIC || "", "logo.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      devTools: !electron.app.isPackaged,
      nodeIntegration: false,
      contextIsolation: true
    }
  });
  electron.Menu.setApplicationMenu(null);
  if (VITE_DEV_SERVER_URL) {
    win.loadURL(VITE_DEV_SERVER_URL);
  } else {
    win.loadFile(path.join(process.env.DIST || "", "index.html"));
  }
  win.once("ready-to-show", () => win == null ? void 0 : win.show());
}
electron.app.whenReady().then(() => {
  createWindow();
  new Ipc(win, API_BASE_URL);
  console.log(`[API] Desktop application configured for ${API_BASE_URL}`);
});
electron.app.on("window-all-closed", () => {
  if (process.platform !== "darwin")
    electron.app.quit();
});
electron.app.on("activate", () => {
  if (electron.BrowserWindow.getAllWindows().length === 0)
    createWindow();
});
